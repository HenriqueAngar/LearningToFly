    // CODIGO PRINCIPAL

// variaveis

placar = 0;

function setup() {
  createCanvas(900, 650);
  trilha.loop();
}

function draw() {
  background(iFundo);
  mostrarAviao();
  moverAviaoY();
  moverAviaoX();
  mostrarUrubus();
  moverUrubus();
  veColisao();
  mostraPlacar();
}

function mostraPlacar(){
    fill(color(255,140,0))
    textSize(40)
    text("impactos "+placar,25,40)
}
